import { expect, it } from 'vitest';

import { normalizeNativeLayout } from '../src/figma-native-layout.js';
import { normalizeFigmaNativeNodes, compareFigmaCaptureNodes } from '../src/figma-native-nodes.js';

it('converts native automatic layout, asymmetric padding and explicit bounds independently', () => {
  const result = normalizeNativeLayout(
    {
      stackMode: 'VERTICAL',
      stackPrimarySizing: 'FIXED',
      stackCounterSizing: 'RESIZE_TO_FIT_WITH_IMPLICIT_SIZE',
      stackPrimaryAlignItems: 'SPACE_EVENLY',
      stackCounterAlignItems: 'CENTER',
      stackHorizontalPadding: 20,
      stackPaddingRight: 12,
      stackVerticalPadding: 8,
      stackPaddingBottom: 4,
      stackSpacing: -2,
      stackWrap: 'WRAP',
      stackCounterSpacing: 6,
      stackReverseZIndex: true,
      minSize: { x: 100 },
      maxSize: { y: 500 },
      mask: true,
      maskType: 'OUTLINE',
      horizontalConstraint: 'SCALE',
      verticalConstraint: 'MAX',
      stackPositioning: 'ABSOLUTE',
    },
    true,
  );
  expect(result.unknown).toEqual([]);
  expect(result.values).toMatchObject({
    layoutMode: 'VERTICAL',
    primaryAxisSizingMode: 'FIXED',
    counterAxisSizingMode: 'AUTO',
    primaryAxisAlignItems: 'SPACE_BETWEEN',
    counterAxisAlignItems: 'CENTER',
    paddingLeft: 20,
    paddingRight: 12,
    paddingTop: 8,
    paddingBottom: 4,
    itemSpacing: -2,
    layoutWrap: 'WRAP',
    counterAxisSpacing: 6,
    itemReverseZIndex: true,
    minWidth: 100,
    minHeight: null,
    maxWidth: null,
    maxHeight: 500,
    isMask: true,
    maskType: 'VECTOR',
    constraints: { horizontal: 'SCALE', vertical: 'MAX' },
    layoutPositioning: 'ABSOLUTE',
  });
});

it('leaves unsupported and nonfinite layout fields unknown instead of applying defaults', () => {
  const result = normalizeNativeLayout(
    { stackMode: 'GRID', stackSpacing: Infinity, stackPrimarySizing: 'future', maskType: 'future' },
    true,
  );
  expect(result.unknown).toEqual(
    expect.arrayContaining(['layoutMode', 'itemSpacing', 'primaryAxisSizingMode', 'maskType']),
  );
  expect(result.values).not.toHaveProperty('layoutMode');
  expect(normalizeNativeLayout({ stackPadding: 10 }, true).unknown).toContain(
    'legacy-stack-layout',
  );
  expect(normalizeNativeLayout({}, false).values).not.toHaveProperty('layoutMode');
});

it('normalizes and compares actual frame layout through the node collector', () => {
  const node = {
    guid: { sessionID: 1, localID: 1 },
    type: 'FRAME',
    name: 'Stack',
    stackMode: 'HORIZONTAL',
    stackSpacing: 5,
  };
  const result = normalizeFigmaNativeNodes({ nodeChanges: [node] }, '1:1');
  expect(result.nodes[0]).toMatchObject({
    layoutMode: 'HORIZONTAL',
    itemSpacing: 5,
    maskType: 'ALPHA',
  });
  const comparison = compareFigmaCaptureNodes(result.nodes, [
    { id: '1:1', itemSpacing: 6, layoutMode: 'HORIZONTAL' },
  ]);
  expect(comparison.differences).toEqual([
    { nodeId: '1:1', field: 'itemSpacing', actual: 5, expected: 6 },
  ]);
});
