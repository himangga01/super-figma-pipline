type Row = Record<string, unknown>;
export const NATIVE_LAYOUT_FIELDS = [
  'isMask',
  'maskType',
  'layoutPositioning',
  'minWidth',
  'minHeight',
  'maxWidth',
  'maxHeight',
  'constraints',
  'layoutMode',
  'layoutWrap',
  'primaryAxisAlignItems',
  'counterAxisAlignItems',
  'primaryAxisSizingMode',
  'counterAxisSizingMode',
  'paddingLeft',
  'paddingTop',
  'paddingRight',
  'paddingBottom',
  'itemSpacing',
  'counterAxisSpacing',
  'itemReverseZIndex',
  'counterAxisAlignContent',
] as const;
const object = (value: unknown): Row =>
  value && typeof value === 'object' && !Array.isArray(value) ? (value as Row) : {};
const enumValue = (value: unknown, allowed: readonly string[], fallback: string) =>
  value === undefined ? fallback : allowed.includes(String(value)) ? value : undefined;
const numeric = (value: unknown, fallback: number | null) =>
  value === undefined
    ? fallback
    : typeof value === 'number' && Number.isFinite(value)
      ? value
      : undefined;
const boolean = (value: unknown, fallback: boolean) =>
  value === undefined ? fallback : typeof value === 'boolean' ? value : undefined;
const sizing = (value: unknown, fallback: string) =>
  value === undefined
    ? fallback
    : value === 'FIXED'
      ? 'FIXED'
      : value === 'RESIZE_TO_FIT' || value === 'RESIZE_TO_FIT_WITH_IMPLICIT_SIZE'
        ? 'AUTO'
        : undefined;

/** Interpret recorded native layout values; unsupported enum forms remain absent. */
export function normalizeNativeLayout(node: Row, container: boolean) {
  const values: Row = {};
  const unknown: string[] = [];
  const set = (key: string, value: unknown) => {
    if (value === undefined) unknown.push(key);
    else values[key] = value;
  };
  set('isMask', boolean(node.mask, false));
  set(
    'maskType',
    node.maskType === 'OUTLINE' || (node.maskType === undefined && node.maskIsOutline === true)
      ? 'VECTOR'
      : enumValue(node.maskType, ['ALPHA', 'LUMINANCE'], 'ALPHA'),
  );
  set('layoutPositioning', enumValue(node.stackPositioning, ['AUTO', 'ABSOLUTE'], 'AUTO'));
  for (const bound of ['min', 'max']) {
    const raw = node[`${bound}Size`];
    if (raw !== undefined && (raw === null || typeof raw !== 'object' || Array.isArray(raw))) {
      unknown.push(`${bound}Width`, `${bound}Height`);
      continue;
    }
    const size = object(raw);
    set(`${bound}Width`, numeric(size.x, null));
    set(`${bound}Height`, numeric(size.y, null));
  }
  const constraints = ['MIN', 'MAX', 'CENTER', 'STRETCH', 'SCALE'];
  const horizontal = enumValue(node.horizontalConstraint, constraints, 'MIN');
  const vertical = enumValue(node.verticalConstraint, constraints, 'MIN');
  set(
    'constraints',
    horizontal === undefined || vertical === undefined ? undefined : { horizontal, vertical },
  );
  if (!container) return { values, unknown };
  const legacy = [
    'stackPadding',
    'stackCounterAlign',
    'stackJustify',
    'stackAlign',
    'stackWidth',
    'stackHeight',
  ];
  if (legacy.some(key => Object.hasOwn(node, key))) {
    unknown.push('legacy-stack-layout');
    return { values, unknown };
  }
  set('layoutMode', enumValue(node.stackMode, ['NONE', 'HORIZONTAL', 'VERTICAL'], 'NONE'));
  set('layoutWrap', enumValue(node.stackWrap, ['NO_WRAP', 'WRAP'], 'NO_WRAP'));
  set(
    'primaryAxisAlignItems',
    node.stackPrimaryAlignItems === 'SPACE_EVENLY'
      ? 'SPACE_BETWEEN'
      : enumValue(node.stackPrimaryAlignItems, ['MIN', 'MAX', 'CENTER'], 'MIN'),
  );
  set(
    'counterAxisAlignItems',
    enumValue(node.stackCounterAlignItems, ['MIN', 'MAX', 'CENTER', 'BASELINE'], 'MIN'),
  );
  set('primaryAxisSizingMode', sizing(node.stackPrimarySizing, 'AUTO'));
  set('counterAxisSizingMode', sizing(node.stackCounterSizing, 'FIXED'));
  for (const [key, source] of [
    ['paddingLeft', 'stackHorizontalPadding'],
    ['paddingTop', 'stackVerticalPadding'],
    ['paddingRight', 'stackPaddingRight'],
    ['paddingBottom', 'stackPaddingBottom'],
    ['itemSpacing', 'stackSpacing'],
    ['counterAxisSpacing', 'stackCounterSpacing'],
  ] as const)
    set(key, numeric(node[source], 0));
  set('itemReverseZIndex', boolean(node.stackReverseZIndex, false));
  set(
    'counterAxisAlignContent',
    enumValue(node.stackCounterAlignContent, ['AUTO', 'SPACE_BETWEEN'], 'AUTO'),
  );
  return { values, unknown };
}
