# Reboot handoff: October 4 evening

Prepared at approximately 21:35 KST on October 4, 2026, at the owner's request. This supersedes the operational state in the [earlier handoff](reboot-2026-10-04.md), preserving its historical evidence. No reboot, new commit or push was performed.

## Read first

Read [AGENTS.md](../../AGENTS.md), the shared analysis policy, [service analysis](../service-analysis.md), [complete collection](../testing/2026-10-04-ecommerce-parity/README.md), [native behavior repairs](../testing/2026-10-04-ecommerce-parity/native-behavior/README.md), and [the latest control repair](../testing/2026-10-04-ecommerce-parity/control-poll/README.md). Keep all new Markdown in English. Use only service-owned Chrome/Playwright/CDP, CLI, MCP integration and validators for acceptance. No Codex browser/CUA/Figma connector, Superpowers or Docker. Do not automate browser approvals or reinstall Orca/hooks.

## Saved source and verification

| Item | Recorded state |
| --- | --- |
| Repository | `C:/2026_project/super-figma-pipline` |
| Branch / published HEAD | `remediation/2026-09-27` / `5b9343efc82ef47ba56f412acbd4eee5a328d335` |
| Main/native service source | `sha256:fc47c9f0f64114d700e4da3d026c2070925842f8d5ea433ddb929824c5f43263` |
| Owner Git index SHA-256 | `5a79352238185329aee8c904a5158b713ba9645d7af966917d09c2930652500a`, unchanged |
| Native working copy | `.worktrees/baseline/service` |
| Latest completed whole check | `1dac9a33-07f8-44fd-83b0-65026f8ac713`, source `e2755bc7...` |
| Completed check result | All 16 gates; 4,748 passed, zero failed, 20 existing skips; all 37 mandatory Chrome cases passed; separate artifact-content case passed |
| Newer control repair | Eleven real-HTTP tests, CLI typecheck/build, scoped lint/format and provenance passed |
| Interrupted whole check | `b4a7a8fa-cec6-4a0a-bc3a-b3d0c491298a`, source `fc47c9f0...` |

The latest whole check completed static/build gates and reached tests. The owner then requested reboot preparation. Its exact Node controller (PID 19576, started at 21:28 KST) and owned descendants were stopped after checking process identity. The stored pointer remains `pending`; **this attempt is interrupted, not passed**. Do not reinterpret its missing terminal report as success or alter its UUID/deadlines. [The checkpoint](2026-10-04-evening/checkpoint.json) and copied [pointer](2026-10-04-evening/interrupted-source-pointer.json)/[report](2026-10-04-evening/interrupted-source-report.json) preserve this distinction. Run a fresh whole check after restart.

The latest alternate review index is `.worktrees/baseline/service/.cache/control-poll-20261004.index`. Manifest verification covers 53 semantic changes and four authority paths, with 178 retained forks, three upstreams and 238 vendor rows. Preserve this index and earlier review records. The real owner index was not staged or changed.

## Preserved outputs and backups

CDD Chrome/Scripter R8 completed its C4 candidate, guarded application, applied runtime/visual/interaction checks and final live source freshness. Run: `sfp_portal1_6e77baedbfa0c9c948a44811d8d80d26`. Candidate/applied hash: `sha256:e424d2eeaea2faec441255fe558b9b8ca77f0dc695503822d3f8cdf721152848`.

The applied output is `.worktrees/_cache/cdd-service-outputs/cdd-chrome-frontend-r8`. All **44 files, 19,284,760 bytes**, were rehashed against the candidate manifest during this handoff. The [ZIP backup](2026-10-04-evening/cdd-chrome-frontend-r8.zip) has 44 independently rehashed entries; [its receipt](2026-10-04-evening/cdd-r8-backup.json) and [file manifest](2026-10-04-evening/cdd-r8-files.json) record the hashes. ZIP SHA-256: `7826319bb8780bb67e5347b95fec0702a73c6ac9544c8f242d1a19563686f74e`. Preserve R7 and its earlier backup too. Do not use CDD output as reference frontend code for eCommerce.

[The source-change backup receipt](2026-10-04-evening/source-changes-backup.json) identifies the tracked and untracked work saved in a separate ZIP. This local backup is not a Git commit or push. Private runtime state, credentials, raw design archives and caches are excluded from that source archive.

## Current product evidence

- eCommerce preparation R2 captured 3,198 nodes, 11 roots and all 283 assets (101,154,854 bytes), with complete ordered reobservation. It has no generated frontend.
- Independently collected native inputs compare at 124,734 eCommerce positions and 8,778 CDD positions. Unexplained differences in the declared fields are zero; 408/73 representation differences remain recorded. All 66 eCommerce click-navigation actions now match. Full native capture/admission remains false.
- Implemented repairs cover identity/style/geometry/font/vector interpretation, supported layout/mask/bounds, instance placement and single-action prototype fragments. Effects, additional node/catalog/variable semantics, independent SVG/root-PNG exports and portal admission remain open.
- Candidate capacity was increased from 64 MiB to 96 MiB to preserve the 89,090,574-byte original image set, with unchanged per-file/submission and 128 MiB working-copy limits. It has bounded tests but no live eCommerce candidate/application yet.
- The latest CLI repair retries only one bodyless control GET after `ECONNRESET`, preserving the original timeout, credentials and cumulative byte budget. Mutations and structured HTTP errors are never replayed.

## Unresolved live preparation failures

R3 attempted five confirmed frontend demo workflows and 89 explicit scope mappings. It encountered a polling connection reset; the client cancelled after dispatch and public state became `outcome-unknown` / `OPERATION_CANCELLED_AFTER_DISPATCH`. The bounded read-retry repair was then implemented and tested.

R4 used a separate context/target after that repair. It encountered **`CONTROL_REQUEST_FAILED (500)`**, again followed by cancellation after dispatch. Its public state is also `outcome-unknown`. The underlying server error is **not diagnosed or fixed**. No R3/R4 plan or target frontend was produced; the 89 unresolved R2 workflow issues are not accepted as resolved. Do not automatically replay either issued operation. Preserve partial capture artifacts and both public operation records.

Next diagnosis: instrument the service's exact failing control route with bounded, non-secret diagnostics and reproduce the HTTP 500. The generic fallback is in `packages/mcp/src/election/leader-endpoints.ts`; possible causes before the control handler have not been established. Do not waive authentication/integrity failures or broaden the GET retry to blanket HTTP 500 retries. Helpers must retain operation IDs and progress, as the R4 helper now does.

Private on-disk continuation locations (preserve; do not publish their contents):

| Purpose | Location relative to repository |
| --- | --- |
| Service owner state | `.worktrees/_cache/cdd-native-appdata/SuperFigmaPipeline` |
| Separate verification state | `.worktrees/_cache/verification-20261004-r8-appdata` |
| CDD R8 context | `.worktrees/_cache/cdd-codegen-context-20261004-r8` |
| Complete eCommerce R2 context | `.worktrees/_cache/ecommerce-service-context-20261004-prep-r2` |
| Failed R3 / R4 contexts | `.worktrees/_cache/ecommerce-service-context-20261004-prep-r3` and `...-r4` |
| Fresh independent native input | `.worktrees/_cache/live-ecommerce-native-refresh-20261004/4IBhv1d8hEclifZQrOYxHS-1791110752199-869e9afe/document.fig` |
| Latest comparison outputs | `.worktrees/_cache/ecommerce-parity-behavior-20261004` and `.worktrees/_cache/cdd-parity-behavior-20261004` |

## Restart sequence

At 21:33 KST the retained daemon was healthy on port 3055, build `b667c982...`, Chrome `connected`, zero paired Desktop plugins. It predates newer source changes. The owned verification tree was stopped; the source daemon and user Chrome were preserved. Do not assume their connection survives reboot.

From `.worktrees/baseline/service`, establish the same service state explicitly:

```powershell
$sfpUserLocalAppData = $env:LOCALAPPDATA
$env:SFP_CHROME_USER_DATA_DIR = Join-Path $sfpUserLocalAppData 'Google/Chrome/User Data'
$env:LOCALAPPDATA = 'C:/2026_project/super-figma-pipline/.worktrees/_cache/cdd-native-appdata'
$env:PATH = 'C:/2026_project/super-figma-pipline/.worktrees/_cache/bin;' + $env:PATH
node packages/cli/dist/index.mjs status
node packages/cli/dist/index.mjs egress status
```

Start `node packages/mcp/dist/daemon-entry.mjs` in a dedicated service process only if the daemon is absent. Verify the newly started build rather than assuming the old identity. Reopen either requested file using the service's `chrome-open --url` path and let the owner manually approve any new Chrome prompt. Recheck `status`; do not restart a healthy approved daemon repeatedly.

The recorded external-model egress scope allows public, project-code, design-text and design-image classes and expires **October 5 at 00:24:12 KST**. Recheck after restart; if expired, renew only that previously authorized scope through `node packages/cli/dist/index.mjs egress allow`. Do not reset expired portal run deadlines or overwrite applied outputs.

Run fresh complete verification in a separate terminal with `LOCALAPPDATA` set to the verification state above, the cache `bin` on PATH, then `node scripts/run-source-checks.mjs`. After a successful unchanged-source result, use `.cache/save-cdd-full-checks.mjs` and `.cache/run-cdd-artifact-scope.mjs` with a new documentation destination. These same-owner native processes/directories are not an OS sandbox.

The service's local official MCP probe at 21:12 KST returned `fetch failed`; the earlier remote probe required authentication. The owner has been asked to enable Figma Desktop's official Dev Mode MCP server. Test using `figma-mcp probe --endpoint http://127.0.0.1:3845/mcp` through the service CLI; do not use the Codex connector. Desktop development-plugin pairing/live collection also remains unexecuted.

## Required completion order

1. Diagnose the new control-server failure and rerun a valid public preparation flow; finish current-source checks.
2. Finish independent native acquisition and compare it against separate Chrome/Scripter evidence; finish authenticated official MCP and Desktop acquisition.
3. Complete relevant C1–C3 full-portal cases and independent review gates. Preserve the completed CDD Chrome/Scripter C4 result and revalidate affected behavior when changes require it.
4. Run the final eCommerce test with **two separate new frontend outputs, no reference frontend code**, through official MCP and Chrome. Capture preparation and field parity do not establish final acceptance.
5. Refresh canonical reports before claiming completion. Do not commit or push unless requested.
