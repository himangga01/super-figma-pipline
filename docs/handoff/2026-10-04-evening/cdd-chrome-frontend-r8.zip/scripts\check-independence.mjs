import {readFile} from 'node:fs/promises';
import {dirname, isAbsolute, relative, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {API} from 'typescript/unstable/sync';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const packageJson=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
const lock=JSON.parse(await readFile(resolve(root,'package-lock.json'),'utf8'));
for(const versions of [packageJson.dependencies,packageJson.devDependencies])
  for(const version of Object.values(versions??{}))
    if(typeof version!=='string'||!/^\d+\.\d+\.\d+$/.test(version))throw Error('Dependencies must use exact registry versions');
for(const [path,entry] of Object.entries(lock.packages??{})){
  if(path==='')continue;
  if(entry.link||!entry.integrity||!/^https:\/\/registry\.npmjs\.org\//.test(entry.resolved??''))throw Error('Unbound local or external dependency: '+path);
}
const api=new API({cwd:root});
try {
  const config=resolve(root,'tsconfig.json');
  const snapshot=api.updateSnapshot({openProjects:[config]});
  try {
    const project=snapshot.getProject(config);
    if(!project)throw Error('The frontend compiler project was not loaded');
    const files=project.program.getSourceFileNames();
    if(!files.length)throw Error('The compiler input graph is empty');
    for(const file of files){
      const path=relative(root,resolve(file));
      if(isAbsolute(path)||path==='..'||path.startsWith('../')||path.startsWith('..\\'))throw Error('Compiler input escapes this frontend: '+file);
    }
    console.log(JSON.stringify({independent:true,compilerInputs:files.length,referenceFrontendRoots:0}));
  } finally {snapshot.dispose();}
} finally {api.close();}
