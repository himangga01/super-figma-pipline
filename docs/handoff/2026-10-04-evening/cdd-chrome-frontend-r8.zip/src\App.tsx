import { createElement, Fragment, useEffect, useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import guide from './design-1381-285.json';
import mobile from './design-1381-530.json';
import desktop from './design-1381-541.json';
import materials from './design-materials.json';
import coreMaterials from './core-materials.json';
import nativeTextHints from './native-text-layout.json';

// These records came from the service's paginated coding work item, not reference FE code.
type Properties = Record<string, any>;
type Node = { id: string; parentId: string | null; childIds: string[]; properties: Properties };
type Matrix = number[][];
type Locale = 'ko' | 'en';
type Dialog = { kind: 'signin' | 'trial' | 'info'; title?: string } | null;
const all = [...guide, ...mobile, ...desktop] as Node[];
const nodes = new Map(all.map(node => [node.id, node]));
type NativeTextHint = {id:string;characters:string;scale:number;renderedFontSize:number;layout:{baselines:Array<{position:{x:number;y:number};lineHeight:number;firstCharacter:number;endCharacter:number}>;glyphPositions?:Array<{index:number;x:number;y:number}>}};
const nativeLayouts = new Map((nativeTextHints.nodes as NativeTextHint[]).map(node=>[node.id,node]));
const styleRows = (coreMaterials.rows as Properties[]).filter(row=>row.kind==='style').map(row=>row.material.value);
const styleIndex = new Map(styleRows.map((style, index) => [style.id, index]));
const imageAssets = new Map(materials.assets.filter(asset => asset.query.kind === 'image').map(asset => [asset.query.imageHash, '/' + asset.path]));
const vectorAssets = new Map(materials.assets.filter(asset => asset.query.kind === 'svg').map(asset => [asset.query.nodeId, '/' + asset.path]));
const identity: Matrix = [[1, 0, 0], [0, 1, 0]];
const round = (value: number) => Math.round(value * 1e6) / 1e6;
const rgba = (color: Properties, opacity = 1) => `rgba(${round(color.r * 255)},${round(color.g * 255)},${round(color.b * 255)},${round((color.a ?? 1) * opacity)})`;
const normalize = (text: string) => text.replaceAll('\uFEFF', '').replaceAll('\u2028', '\n');
// HTML does not render Figma's Unicode line separators as forced line breaks.
// Keep the original code points in textContent while adding the matching visual break.
const renderText = (text: string) => text.split(/([\u2028\u2029])/u).map((part,index) =>
  /^[\u2028\u2029]$/u.test(part) ? <Fragment key={index}>{part}<br/></Fragment> : part);
const linkedColor = (id: unknown, paint: Properties) => {
  const index=styleIndex.get(id);const source=index===undefined?undefined:styleRows[index]?.paints;
  return source?.length===1&&source[0].type==='SOLID'&&rgba(source[0].color,source[0].opacity??1)===rgba(paint.color,paint.opacity??1)?`var(--paint-${index})`:rgba(paint.color,paint.opacity??1);
};
const translations: Record<string, string> = {
  '로그인': 'Sign in', '한국어': 'English', '이메일 주소': 'Email address', '30일 무료 이용': 'Try free',
  '영화, TV 프로그램을 \n무제한으로.': 'Unlimited films\nand TV programmes.',
  '다양한 디바이스에서 시청하세요. 언제든 해지하실 수 있습니다.': 'Watch on your favourite devices. Cancel anytime.',
  '다양한 디바이스에서 시청하세요. \n언제든 해지하실 수 있습니다.': 'Watch on your devices.\nCancel anytime.',
  '시청할 준비가 되셨나요? 멤버십을 등록하거나 \n재시작하려면 이메일 주소를 입력하세요.': 'Ready to watch? Enter your email\nto start your local demo.',
  '신규 회원만 이 프로모션을 이용하실 수 있습니다.': 'This promotion is for new members.',
  'TV로 즐기세요.': 'Enjoy on your TV.',
  '즐겨 보는 콘텐츠를 저장해 \n오프라인으로 시청하세요.': 'Save your favourites.\nWatch offline.',
  '즐겨 보는 콘텐츠를 저장해\n오프라인으로 시청하세요.': 'Save your favourites.\nWatch offline.',
  '간편하게 저장하고 빈틈없이 즐겨보세요.': 'Save easily. Enjoy every moment.',
  '다양한 디바이스에서 \n시청하세요.': 'Watch on your\nfavourite devices.',
  '기묘한 이야기': 'Stranger Things', '저장 중...': 'Downloading...',
  '자주 묻는 질문': 'FAQ', '고객센터': 'Help centre', '계정': 'Account', '미디어 센터': 'Media centre',
  '투자 정보(IR)': 'Investor relations', '입사 정보': 'Jobs', 'Netflix 지원 디바이스': 'Ways to watch',
  '이용 약관': 'Terms of use', '개인정보': 'Privacy', '쿠키 설정': 'Cookie preferences',
  '회사 정보': 'Corporate information', '문의하기': 'Contact us', '속도 테스트': 'Speed test',
  '법적 고지': 'Legal notices', 'Netflix 오리지널': 'Netflix originals', 'Netflix 대한민국': 'Netflix Korea',
};
function relative(world: Matrix, parent: Matrix) {
  const [[a, c, e], [b, d, f]] = parent;
  const determinant = a * d - b * c;
  if (!determinant) throw new Error('Unsupported singular source transform');
  const [[u, w, x], [v, z, y]] = world;
  return [(d*u-c*v)/determinant, (-b*u+a*v)/determinant, (d*w-c*z)/determinant, (-b*w+a*z)/determinant,
    (d*(x-e)-c*(y-f))/determinant, (-b*(x-e)+a*(y-f))/determinant].map(round);
}
function fontStyle(properties: Properties): CSSProperties {
  const segment = properties.textSegments?.[0] ?? properties;
  const font = typeof properties.fontName === 'object' ? properties.fontName : segment.fontName;
  if (!font?.family || !font?.style) throw new Error(`Effective font unavailable: ${properties.id}`);
  const size = segment.fontSize ?? properties.fontSize;
  const lineHeight = segment.lineHeight ?? properties.lineHeight;
  const spacing = segment.letterSpacing ?? properties.letterSpacing;
  const fill = (segment.fills ?? properties.fills)?.find((paint: Properties) => paint.visible !== false && paint.type === 'SOLID');
  return { fontFamily: `"${font.family}", sans-serif`, fontSize: size,
    fontWeight: segment.fontWeight ?? properties.fontWeight ?? (/bold/i.test(font.style) ? 700 : 400),
    fontStyle: /italic/i.test(font.style) ? 'italic' : 'normal',
    lineHeight: lineHeight?.unit === 'PERCENT' ? String(lineHeight.value/100) : lineHeight?.unit === 'PIXELS' ? `${lineHeight.value}px` : 'normal',
    letterSpacing: spacing?.unit === 'PERCENT' ? size * spacing.value/100 : spacing?.value ?? 0,
    color: fill ? linkedColor(segment.fillStyleId??properties.fillStyleId,fill) : 'inherit',
    textAlign: ({LEFT:'left',CENTER:'center',RIGHT:'right',JUSTIFIED:'justify'} as const)[properties.textAlignHorizontal as 'LEFT'] ?? 'left',
    textDecoration: properties.textDecoration === 'UNDERLINE' ? 'underline' : properties.textDecoration === 'STRIKETHROUGH' ? 'line-through' : 'none',
    whiteSpace: 'pre-wrap', overflowWrap: 'normal', wordBreak: 'normal', textRendering:'geometricPrecision',
  };
}
function gradient(paint: Properties, width: number, height: number) {
  if (paint.type !== 'GRADIENT_LINEAR') throw new Error(`Unsupported gradient ${paint.type}`);
  const [a,c,e] = paint.gradientTransform[0];
  const dx=a/Math.max(width,1e-6),dy=c/Math.max(height,1e-6);
  const angle=90+Math.atan2(dy,dx)*180/Math.PI;
  const length=Math.abs(width*Math.sin(angle*Math.PI/180))+Math.abs(height*Math.cos(angle*Math.PI/180));
  const range=Math.hypot(dx,dy)*length;
  const start=(a+c)/2+e-range/2;
  return `linear-gradient(${angle}deg,${paint.gradientStops.map((stop: Properties) => `${rgba(stop.color, paint.opacity ?? 1)} ${(stop.position-start)/range*100}%`).join(',')})`;
}
function boxStyle(p: Properties): CSSProperties {
  const fill=(p.fills??[]).filter((paint:Properties)=>paint.visible!==false);
  const image=fill.find((paint:Properties)=>paint.type==='IMAGE');
  const stroke=(p.strokes??[]).find((paint:Properties)=>paint.visible!==false&&paint.type==='SOLID');
  return {width:p.width,height:p.height,opacity:p.opacity??1,boxSizing:'border-box',
    gap:p.itemSpacing??0,paddingTop:p.paddingTop??0,paddingRight:p.paddingRight??0,paddingBottom:p.paddingBottom??0,paddingLeft:p.paddingLeft??0,
    minWidth:p.minWidth??undefined,maxWidth:p.maxWidth??undefined,minHeight:p.minHeight??undefined,maxHeight:p.maxHeight??undefined,
    borderRadius:`${p.topLeftRadius??p.cornerRadius??0}px ${p.topRightRadius??p.cornerRadius??0}px ${p.bottomRightRadius??p.cornerRadius??0}px ${p.bottomLeftRadius??p.cornerRadius??0}px`,
    borderColor:stroke?rgba(stroke.color,stroke.opacity??1):undefined,
    backgroundColor:!['TEXT','VECTOR','BOOLEAN_OPERATION'].includes(p.type)&&fill.length===1&&fill[0].type==='SOLID'?linkedColor(p.fillStyleId,fill[0]):undefined,
    ...(image?{backgroundImage:`url("${imageAssets.get(image.imageHash)}")`,backgroundSize:image.scaleMode==='FIT'?'contain':image.scaleMode==='STRETCH'?'100% 100%':'cover',backgroundPosition:'50% 50%',backgroundRepeat:'no-repeat'}:{}),
    overflow:p.clipsContent?'hidden':'visible',pointerEvents:'none',
  };
}
function SourceText({node,tag,style,text,state,overlay,htmlFor,link=false}:{node:Node;tag:string;style:CSSProperties;text:string;state:SceneState;overlay?:ReactNode;htmlFor?:string;link?:boolean}) {
  const element=useRef<HTMLElement|null>(null), baseline=useRef<HTMLSpanElement|null>(null), contents=useRef<HTMLSpanElement|null>(null);
  const [offset,setOffset]=useState({x:0,y:0,ready:false});
  const hint=nativeLayouts.get(node.id);
  const nativeLayout=hint?.characters===text?hint:undefined;
  const glyphPositions=nativeLayout?.layout.glyphPositions;
  const positionedGlyphs=glyphPositions?.length&&/^\s*$/u.test(text.slice(0,glyphPositions[0].index))?glyphPositions:undefined;
  const glyphShadow=(node.properties.effects??[]).filter((effect:Properties)=>effect.visible!==false&&effect.type==='DROP_SHADOW').map((effect:Properties)=>`drop-shadow(${effect.offset.x}px ${effect.offset.y}px ${effect.radius/2}px ${rgba(effect.color)})`).join(' ');
  useLayoutEffect(()=>{
    let active=true;
    void document.fonts.ready.then(()=>{
      if(!active||!element.current||!baseline.current)return;
      if(nativeLayout){
        setOffset({x:0,y:0,ready:true});return;
      }
      if(!contents.current)return;
      const p=node.properties;
      if(text!==p.characters){setOffset({x:0,y:0,ready:true});return;}
      // Shadow render bounds include blur extents, so they cannot anchor glyph ink.
      if(!text||!p.absoluteRenderBounds||p.effects?.some((effect:Properties)=>effect.visible!==false)){
        setOffset({x:0,y:0,ready:true});return;
      }
      const outer=element.current.getBoundingClientRect(), font=getComputedStyle(element.current);
      const previousLeft=parseFloat(getComputedStyle(contents.current).left)||0;
      const rows:Array<{top:number;left:number;text:string}>=[];
      const walker=document.createTreeWalker(contents.current,NodeFilter.SHOW_TEXT);
      for(let current=walker.nextNode();current;current=walker.nextNode()){
        const value=current.textContent??'';
        for(let index=0;index<value.length;index++){
          const range=document.createRange();range.setStart(current,index);range.setEnd(current,index+1);
          const rect=range.getBoundingClientRect();if(rect.width===0)continue;
          let row=rows.at(-1);
          if(!row||Math.abs(row.top-rect.top)>0.5){row={top:rect.top,left:rect.left,text:''};rows.push(row);}
          row.text+=value[index];
        }
      }
      const context=document.createElement('canvas').getContext('2d');
      if(!context||!rows.length){setOffset({x:0,y:0,ready:true});return;}
      context.font=`${font.fontStyle} ${font.fontWeight} ${font.fontSize} ${font.fontFamily}`;
      context.textRendering='geometricPrecision';
      context.letterSpacing=font.letterSpacing==='normal'?'0px':font.letterSpacing;
      const firstBaseline=(baseline.current.getBoundingClientRect().top-outer.top)/state.scale;
      let left=Infinity,top=Infinity;
      for(const row of rows){
        const metrics=context.measureText(row.text);
        left=Math.min(left,(row.left-outer.left)/state.scale-previousLeft-metrics.actualBoundingBoxLeft);
        top=Math.min(top,firstBaseline+(row.top-rows[0].top)/state.scale-metrics.actualBoundingBoxAscent);
      }
      const x=p.absoluteRenderBounds.x-p.absoluteBoundingBox.x-left;
      const y=p.absoluteRenderBounds.y-p.absoluteBoundingBox.y-top;
      if(!Number.isFinite(x)||!Number.isFinite(y))throw new Error('Source glyph bounds are unavailable');
      setOffset({x:round(x),y:round(y),ready:true});
    });
    return()=>{active=false;};
  },[node,text,state.scale,nativeLayout]);
  return createElement(tag,{ref:(value:HTMLElement|null)=>{element.current=value;},'data-sfp-node':node.id,'data-sfp-text':true,'data-ink-aligned':offset.ready,
    className:link?'source-link':'source-text',style:{...style,...(link?{pointerEvents:'auto'}:{})},htmlFor,
    ...(link?{href:'#information',onClick:(event:{preventDefault():void})=>{event.preventDefault();state.open({kind:'info',title:text});}}:{})},
    overlay,<span ref={baseline} aria-hidden="true" style={{display:'inline-block',width:0,height:0,verticalAlign:'baseline'}}/>,
    nativeLayout?<svg role="img" aria-label={text} focusable="false" width={node.properties.width} height={node.properties.height} viewBox={`0 0 ${node.properties.width/nativeLayout.renderedFontSize} ${node.properties.height/nativeLayout.renderedFontSize}`} style={{position:'absolute',inset:0,overflow:'visible',pointerEvents:'none',filter:glyphShadow||undefined}}>
      {positionedGlyphs?<text xmlSpace="preserve" fill="currentColor" style={{fontFamily:style.fontFamily,fontWeight:style.fontWeight,fontSize:1,fontStyle:style.fontStyle,letterSpacing:0,textDecoration:style.textDecoration,textShadow:'none',whiteSpace:'pre',textRendering:'geometricPrecision'}}>{text.slice(0,positionedGlyphs[0].index)}{positionedGlyphs.map((glyph,index)=><tspan key={glyph.index} x={glyph.x*nativeLayout.scale/nativeLayout.renderedFontSize} y={glyph.y*nativeLayout.scale/nativeLayout.renderedFontSize}>{text.slice(glyph.index,positionedGlyphs[index+1]?.index??text.length)}</tspan>)}</text>:
      nativeLayout.layout.baselines.map((line,index)=><text key={index} x={line.position.x*nativeLayout.scale/nativeLayout.renderedFontSize} y={line.position.y*nativeLayout.scale/nativeLayout.renderedFontSize} xmlSpace="preserve" fill="currentColor" style={{fontFamily:style.fontFamily,fontWeight:style.fontWeight,fontSize:1,fontStyle:style.fontStyle,letterSpacing:Number(style.letterSpacing??0)/nativeLayout.renderedFontSize,textDecoration:style.textDecoration,textShadow:'none',whiteSpace:'pre',textRendering:'geometricPrecision'}}>{text.slice(line.firstCharacter,line.endCharacter)}</text>)}
    </svg>:
    <span ref={contents} style={{position:'relative',left:offset.x,top:offset.y,pointerEvents:'none',...(hint?{fontSize:hint.renderedFontSize,lineHeight:`${hint.layout.baselines[0].lineHeight*hint.scale}px`}:{})}}>{renderText(text)}</span>);
}
function ReducedMotionRaster({src,fit,background}: {src:string;fit:'cover'|'contain'|'fill';background?:string}) {
  const [reduced,setReduced]=useState(()=>matchMedia('(prefers-reduced-motion: reduce)').matches);
  const canvas=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{const query=matchMedia('(prefers-reduced-motion: reduce)');const update=()=>setReduced(query.matches);query.addEventListener('change',update);return()=>query.removeEventListener('change',update);},[]);
  useEffect(()=>{
    const target=canvas.current;if(!reduced||!target)return;
    const controller=new AbortController();let active=true;
    delete target.dataset.ready;
    void fetch(src,{signal:controller.signal}).then(response=>{if(!response.ok)throw new Error('Original image unavailable');return response.blob();}).then(blob=>createImageBitmap(blob)).then(bitmap=>{
      if(active){target.width=bitmap.width;target.height=bitmap.height;const context=target.getContext('2d');if(!context)throw new Error('Canvas unavailable');context.drawImage(bitmap,0,0);const pixels=context.getImageData(0,0,bitmap.width,bitmap.height).data;for(let at=3;at<pixels.length;at+=4)if(pixels[at]!==255&&!background)throw new Error('Transparent animation requires a captured opaque backdrop');target.dataset.ready='true';}
      bitmap.close();
    }).catch(error=>{if(active){target.dataset.error=String(error);console.error(error);}});
    return()=>{active=false;controller.abort();};
  },[src,reduced,background]);
  // The original GIF remains the normal-motion background and the load fallback.
  // The reduced-motion image is decoded from those same original bytes.
  return reduced?<canvas ref={canvas} aria-hidden="true" style={{position:'absolute',inset:0,width:'100%',height:'100%',objectFit:fit,pointerEvents:'none',borderRadius:'inherit',backgroundColor:background}}/>:null;
}
function Paints({properties}: {properties: Properties}) {
  return <>{[...(properties.fills ?? [])].filter((paint: Properties)=>paint.visible!==false).map((paint: Properties,index:number)=> {
    const style: CSSProperties = {position:'absolute',inset:0,width:'100%',height:'100%',pointerEvents:'none',borderRadius:'inherit'};
    if(paint.type==='SOLID') return properties.fills.filter((value:Properties)=>value.visible!==false).length===1?null:<span key={index} aria-hidden="true" style={{...style,background:rgba(paint.color,paint.opacity??1)}}/>;
    if(paint.type.startsWith('GRADIENT_')) return <span key={index} aria-hidden="true" style={{...style,background:gradient(paint,properties.width,properties.height)}}/>;
    if(paint.type==='IMAGE') {
      const src=imageAssets.get(paint.imageHash); if(!src)throw new Error(`Captured image unavailable: ${paint.imageHash}`);
      if(index!==0)throw new Error('The captured image stack needs an explicit compositor');
      let ancestor=nodes.get(properties.id)?.parentId;let backdrop:string|undefined;
      while(ancestor){const parent=nodes.get(ancestor)!;const fills=(parent.properties.fills??[]).filter((value:Properties)=>value.visible!==false);if(fills.length===1&&fills[0].type==='SOLID'&&(fills[0].opacity??1)===1&&(parent.properties.opacity??1)===1){backdrop=linkedColor(parent.properties.fillStyleId,fills[0]);break;}ancestor=parent.parentId;}
      const still=src.endsWith('.gif')?<ReducedMotionRaster src={src} fit={paint.scaleMode==='FIT'?'contain':paint.scaleMode==='STRETCH'?'fill':'cover'} background={backdrop}/>:null;
      if((paint.opacity??1)===1)return <Fragment key={index}>{still}</Fragment>;
      let parent=nodes.get(properties.id)?.parentId;let color:Properties|undefined;
      while(parent){const node=nodes.get(parent)!;const fills=node.properties.fills??[];if(fills.length===1&&fills[0].type==='SOLID'&&(fills[0].opacity??1)===1){color=fills[0].color;break;}parent=node.parentId;}
      if(!color)throw new Error('The image opacity backdrop is unresolved');
      return <Fragment key={index}>{still}<span aria-hidden="true" style={{...style,background:rgba(color,1-paint.opacity)}}/></Fragment>;
    }
    throw new Error(`Unsupported paint ${paint.type}`);
  })}</>;
}
const emailNodes = new Set(['I1381:431;1379:265;1381:941','I1604:1325;1379:329;1378:421']);
const signupNodes = new Set(['I1381:431;1379:265;1378:464','I1604:1325;1379:329;1378:416']);
const signinNodes = new Set(['I1381:290;1379:457;1379:147','I1381:542;1381:247;1379:136']);
const localeNodes = new Set(['I1381:290;1379:457;1396:452','I1381:290;1379:619;1379:493','I1381:542;1381:190;1379:580','I1381:542;1381:247;1396:423']);
function isFooterLink(node: Node) {
  const parent=node.parentId ? nodes.get(node.parentId) : undefined;
  return node.properties.type==='TEXT' && parent?.properties.name==='Navigation';
}
type SceneState = {locale:Locale; setLocale(value:Locale):void; email:string; setEmail(value:string):void; invalid:boolean; submit():void; open(dialog:Dialog):void; scale:number};
function LocaleControl({id,style,state,children}: {id:string;style:CSSProperties;state:SceneState;children:ReactNode}) {
  const [expanded,setExpanded]=useState(false);
  const [choice,setChoice]=useState<Locale>(state.locale);
  const control=useRef<HTMLButtonElement>(null);
  const popup=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const element=popup.current;if(!expanded||!element)return;
    element.showPopover();
    const closed=()=>{if(!element.matches(':popover-open'))setExpanded(false);};
    element.addEventListener('toggle',closed);
    return()=>{element.removeEventListener('toggle',closed);if(element.matches(':popover-open'))element.hidePopover();};
  },[expanded]);
  const choose=(value:Locale)=>{state.setLocale(value);setExpanded(false);control.current?.focus();};
  return <div style={{...style,overflow:'visible'}}>
    <button ref={control} type="button" data-sfp-node={id} role="combobox" aria-haspopup="listbox" aria-expanded={expanded} aria-controls={'options-'+id} aria-label={state.locale==='ko'?'표시 언어':'Display language'} className="source-button locale-control" style={{...boxStyle(nodes.get(id)!.properties),position:'absolute',inset:0,pointerEvents:'auto'}}
      onClick={()=>{setChoice(state.locale);setExpanded(!expanded);}}
      onKeyDown={event=>{if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)){event.preventDefault();setExpanded(true);setChoice(event.key==='Home'?'ko':event.key==='End'?'en':choice==='ko'?'en':'ko');}else if(event.key==='Enter'&&expanded){event.preventDefault();choose(choice);}else if(event.key==='Escape'){event.preventDefault();setExpanded(false);}}}>{children}</button>
    {expanded&&<div ref={popup} popover="auto" id={'options-'+id} role="listbox" className="locale-options" style={{left:control.current?.getBoundingClientRect().left??0,top:Math.min(window.innerHeight-96,control.current?.getBoundingClientRect().bottom??0)}}>{(['ko','en'] as const).map(value=><button key={value} type="button" role="option" aria-selected={choice===value} onClick={()=>choose(value)}>{value==='ko'?'한국어':'English'}</button>)}</div>}
  </div>;
}
function Layer({id,parentWorld,state,ordered}: {id:string;parentWorld:Matrix;state:SceneState;ordered?:string[]}) {
  const node=nodes.get(id)!; const p=node.properties;
  if(p.visible===false)return null;
  const world=p.absoluteTransform??identity;
  const style:CSSProperties={...boxStyle(p),position:'absolute',left:0,top:0,transform:`matrix(${relative(world,parentWorld).join(',')})`,transformOrigin:'0 0'};
  const strokes=(p.strokes??[]).filter((paint:Properties)=>paint.visible!==false);
  let border:ReactNode=null;
  if(strokes.length){const stroke=strokes[0];if(stroke.type==='SOLID')border=<span aria-hidden="true" style={{position:'absolute',inset:0,pointerEvents:'none',borderRadius:'inherit',borderStyle:'solid',borderColor:rgba(stroke.color,stroke.opacity??1),borderWidth:`${p.strokeTopWeight??p.strokeWeight}px ${p.strokeRightWeight??p.strokeWeight}px ${p.strokeBottomWeight??p.strokeWeight}px ${p.strokeLeftWeight??p.strokeWeight}px`}}/>;}
  if(strokes.length===1&&strokes[0].type==='SOLID'&&p.strokeAlign==='INSIDE'&&p.fillGeometry?.length&&p.strokeGeometry?.length){
    const clip='stroke-'+id.replace(/[^a-z0-9_-]/gi,'_');
    border=<svg aria-hidden="true" width={p.width} height={p.height} viewBox={`0 0 ${p.width} ${p.height}`} style={{position:'absolute',inset:0,pointerEvents:'none',overflow:'visible'}}>
      <defs><clipPath id={clip}>{p.fillGeometry.map((geometry:Properties,index:number)=><path key={index} d={geometry.data} clipRule={geometry.windingRule==='EVENODD'?'evenodd':'nonzero'}/>)}</clipPath></defs>
      <g clipPath={`url(#${clip})`} fill={rgba(strokes[0].color,strokes[0].opacity??1)}>{p.strokeGeometry.map((geometry:Properties,index:number)=><path key={index} d={geometry.data} fillRule={geometry.windingRule==='EVENODD'?'evenodd':'nonzero'}/>)}</g>
    </svg>;
  }
  const shadow=(p.effects??[]).filter((effect:Properties)=>effect.visible!==false&&effect.type==='DROP_SHADOW').map((effect:Properties)=>`${effect.offset.x}px ${effect.offset.y}px ${effect.radius}px ${effect.spread??0}px ${rgba(effect.color)}`).join(',');
  if(shadow){if(p.type==='TEXT')style.textShadow=(p.effects??[]).filter((effect:Properties)=>effect.visible!==false&&effect.type==='DROP_SHADOW').map((effect:Properties)=>`${effect.offset.x}px ${effect.offset.y}px ${effect.radius}px ${rgba(effect.color)}`).join(',');else style.boxShadow=shadow;}
  const children=(ordered??node.childIds).map(child=><Layer key={child} id={child} parentWorld={world} state={state}/>);
  if(p.type==='TEXT') {
    const original=normalize(p.characters??'');
    const text=state.locale==='en'?(translations[original]??original):p.characters;
    const textStyle={...style,...fontStyle(p)};
    if(isFooterLink(node))return <SourceText node={node} tag="a" style={textStyle} text={text} state={state} link/>;
    const heading=id==='1381:286'||original.startsWith('영화, TV')?'h1':(p.fontSize>=24&&p.fontWeight>=700?'h2':'span');
    return <SourceText node={node} tag={heading} style={textStyle} text={text} state={state}/>;
  }
  if(vectorAssets.has(id))return <img data-sfp-node={id} src={vectorAssets.get(id)} style={style} alt={p.name==='Logo'?'Netflix':''} draggable={false}/>;
  if(emailNodes.has(id)) {
    const child=nodes.get(node.childIds.find(child=>nodes.get(child)?.properties.type==='TEXT')??'');
    const typography=child?fontStyle(child.properties):{};
    if(!child)throw new Error('Captured email label is missing');
    const labelX=child.properties.x??20,labelY=child.properties.y??0;
    const labelText=state.locale==='ko'?child.properties.characters:'Email address';
    return <div style={style} className="source-input">
      <SourceText node={child} tag="label" htmlFor={'email-'+id} style={{...boxStyle(child.properties),...typography,position:'absolute',left:labelX,top:labelY}} text={state.email?'':labelText} state={state} overlay={
        <input id={'email-'+id} data-sfp-node={id} aria-label={state.locale==='ko'?'이메일 주소':'Email address'} aria-invalid={state.invalid} aria-describedby={state.invalid?'trial-error':undefined} type="email" autoComplete="email" value={state.email} onChange={event=>state.setEmail(event.target.value)} onKeyDown={event=>{if(event.key==='Enter')state.submit();}} style={{...boxStyle(p),...typography,position:'absolute',left:-labelX,top:-labelY,textIndent:labelX,pointerEvents:'auto',color:state.email?typography.color:'transparent'}}/>
      }/>{border}
      {state.invalid&&<span id="trial-error" role="alert" className="trial-error">{state.locale==='ko'?'올바른 이메일 주소를 입력하세요.':'Enter a valid email address.'}</span>}
    </div>;
  }
  if(localeNodes.has(id))return <LocaleControl id={id} style={style} state={state}><Paints properties={p}/>{children}{border}</LocaleControl>;
  if(signupNodes.has(id)||signinNodes.has(id))return <button type="button" data-sfp-node={id} style={{...style,pointerEvents:'auto'}} className="source-button" onClick={()=>signupNodes.has(id)?state.submit():state.open({kind:'signin'})}><Paints properties={p}/>{children}{border}</button>;
  const Tag=p.name==='Header'?'header':p.name==='Footer'?'footer':p.name==='List / Services'?'section':'div';
  return <Tag data-sfp-node={id} style={style}><Paints properties={p}/>{children}{border}</Tag>;
}
function DemoDialog({dialog,close,locale,email}: {dialog:NonNullable<Dialog>;close():void;locale:Locale;email:string}) {
  const box=useRef<HTMLDialogElement>(null);
  const [value,setValue]=useState(email);
  const [invalid,setInvalid]=useState(false);
  const [confirmed,setConfirmed]=useState(false);
  useEffect(()=>{const element=box.current!;element.showModal();return()=>element.close();},[]);
  const ko=locale==='ko';
  const title=dialog.kind==='signin'?(ko?'로그인 데모':'Sign-in demo'):dialog.kind==='trial'?(ko?'체험 신청 데모':'Trial demo'):(dialog.title??(ko?'안내':'Information'));
  return <dialog ref={box} onCancel={event=>{event.preventDefault();close();}} onClick={event=>{if(event.target===box.current)close();}} aria-labelledby="dialog-title" className="demo-dialog">
    <h2 id="dialog-title">{title}</h2>
    <p>{ko?'이 화면은 로컬 프런트엔드 데모입니다. 실제 계정이나 구독을 만들지 않습니다.':'This is a local frontend demo. It does not create an account or subscription.'}</p>
    {dialog.kind==='signin'&&!confirmed&&<form onSubmit={event=>{event.preventDefault();const valid=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);setInvalid(!valid);if(valid)setConfirmed(true);else box.current!.querySelector('input')!.focus();}} noValidate>
      <label htmlFor="demo-email">{ko?'이메일 주소':'Email address'}</label>
      <input id="demo-email" type="email" value={value} onChange={event=>setValue(event.target.value)} aria-invalid={invalid} aria-describedby={invalid?'dialog-error':undefined}/>
      {invalid&&<p id="dialog-error" role="alert">{ko?'올바른 이메일 주소를 입력하세요.':'Enter a valid email address.'}</p>}
      <button type="submit">{ko?'데모 확인':'Continue demo'}</button>
    </form>}
    {(confirmed||dialog.kind==='trial')&&<p role="status" data-demo-confirmed="true">{ko?'데모 입력이 확인되었습니다. 이메일은 전송되지 않았습니다.':'Demo input confirmed. No email was sent.'}</p>}
    <button type="button" onClick={close} className="close-dialog">{ko?'닫기':'Close'}</button>
  </dialog>;
}
export default function App() {
  const [width,setWidth]=useState(window.innerWidth);
  const [locale,setLocaleState]=useState<Locale>(()=>localStorage.getItem('cdd.locale')==='en'?'en':'ko');
  const [email,setEmail]=useState(''); const [invalid,setInvalid]=useState(false); const [dialog,setDialog]=useState<Dialog>(null);
  const [mediaReady,setMediaReady]=useState(false);
  const opener=useRef<HTMLElement|null>(null);
  useEffect(()=>{const update=()=>setWidth(window.innerWidth);window.addEventListener('resize',update);return()=>window.removeEventListener('resize',update);},[]);
  const isGuide=window.location.pathname==='/guide';
  const root=nodes.get(isGuide?'1381:285':width<900?'1381:530':'1381:541')!;
  const p=root.properties;const template=root.childIds.map(id=>nodes.get(id)!).find(node=>node.properties.name==='Template');
  const height=Math.max(p.height,template?.properties.height??0,p.absoluteRenderBounds?.height??0);
  const scale=width/p.width;
  useEffect(()=>{
    let frame=0;const started=performance.now();setMediaReady(false);
    const check=()=>{
      const ready=document.fonts.status==='loaded'&&Array.from(document.images).every(image=>image.complete&&image.naturalWidth>0)&&Array.from(document.querySelectorAll('canvas')).every(canvas=>canvas.dataset.ready==='true')&&Array.from(document.querySelectorAll<HTMLElement>('[data-sfp-text]')).every(element=>element.dataset.inkAligned==='true');
      setMediaReady(ready);
      if(!ready&&performance.now()-started<30000)frame=requestAnimationFrame(check);
    };
    frame=requestAnimationFrame(check);return()=>cancelAnimationFrame(frame);
  },[root.id]);
  const open=(value:Dialog)=>{opener.current=document.activeElement as HTMLElement;setDialog(value);};
  const close=()=>{setDialog(null);requestAnimationFrame(()=>opener.current?.focus());};
  const setLocale=(value:Locale)=>{setLocaleState(value);localStorage.setItem('cdd.locale',value);};
  const submit=()=>{const valid=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);setInvalid(!valid);if(valid)open({kind:'trial'});else document.querySelector<HTMLInputElement>('.source-input input')?.focus();};
  const state:SceneState={locale,setLocale,email,setEmail:value=>{setEmail(value);if(invalid)setInvalid(false);},invalid,submit,open,scale};
  useLayoutEffect(()=>{document.documentElement.lang=locale;document.body.style.background=isGuide?'white':'#010101';},[locale,isGuide]);
  const tokens=Object.fromEntries(styleRows.flatMap((style,index)=>style.paints?.length===1&&style.paints[0].type==='SOLID'?[[`--paint-${index}`,rgba(style.paints[0].color,style.paints[0].opacity??1)]]:[])) as CSSProperties;
  const footer=template?.childIds.find(id=>nodes.get(id)?.properties.name==='Footer');
  const ordered=template?[...template.childIds.filter(id=>id!==footer),...root.childIds.filter(id=>id!==template.id),...(footer?[footer]:[])]:[];
  return <><a href="#scene" className="skip-link">{locale==='ko'?'본문으로 이동':'Skip to content'}</a>
    <main id="scene" className="stage" style={{width,height:height*scale,...tokens,'--scene-scale':scale} as CSSProperties}>
      <div data-sfp-root={root.id} data-sfp-node={root.id} data-media-ready={mediaReady} data-locale={locale} className="artboard" style={{...boxStyle(p),transform:`scale(${scale})`}}>
        <Paints properties={p}/>
        {template?<Layer id={template.id} parentWorld={p.absoluteTransform??identity} state={state} ordered={ordered}/>:root.childIds.map(id=><Layer key={id} id={id} parentWorld={p.absoluteTransform??identity} state={state}/>)}
        {dialog&&<DemoDialog dialog={dialog} locale={locale} email={email} close={close}/>}
      </div>
    </main>
  </>;
}
